export default{
    getProductData : 'https://dummyjson.com/products?limit=80'
}